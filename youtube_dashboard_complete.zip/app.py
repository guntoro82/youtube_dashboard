
import streamlit as st
import pandas as pd
from visualizations import Visualizations

st.set_page_config(page_title="YouTube Analytics", layout="wide")
st.title("📊 YouTube Channel Analyzer")

uploaded_file = st.file_uploader("📁 Upload CSV dari YouTube Studio", type=["csv"])

if uploaded_file:
    df = pd.read_csv(uploaded_file, parse_dates=['published_at'])

    df['publish_day'] = df['published_at'].dt.day_name()
    df['publish_hour'] = df['published_at'].dt.hour

    viz = Visualizations()

    st.subheader("📅 Timeline Views")
    st.plotly_chart(viz.create_views_timeline(df), use_container_width=True)

    st.subheader("📊 Engagement Distribution")
    st.plotly_chart(viz.create_engagement_distribution(df), use_container_width=True)

    st.subheader("💥 Engagement vs Views")
    st.plotly_chart(viz.create_engagement_vs_views(df), use_container_width=True)

    st.subheader("🗓️ Upload Day Performance")
    st.plotly_chart(viz.create_upload_day_analysis(df), use_container_width=True)

    st.subheader("⏰ Upload Hour Performance")
    st.plotly_chart(viz.create_upload_hour_analysis(df), use_container_width=True)

    st.subheader("🔥 Heatmap Performance")
    st.plotly_chart(viz.create_performance_heatmap(df), use_container_width=True)

    st.subheader("⏱️ Duration Analysis")
    st.plotly_chart(viz.create_duration_analysis(df), use_container_width=True)

    st.subheader("📌 Upload Consistency")
    st.plotly_chart(viz.create_consistency_chart(df), use_container_width=True)
else:
    st.info("Silakan upload file CSV dari YouTube Studio terlebih dahulu.")
